-- SQL schema for leads table
CREATE TABLE leads (...);
