# Database handling for leads with Supabase
