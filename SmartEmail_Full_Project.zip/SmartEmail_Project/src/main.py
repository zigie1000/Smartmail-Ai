# Main app logic integrating all modules
