# Utility functions for the app
