# PromptAgent Email AI

## Features
- Gmail, Outlook, Yahoo OAuth integration
- AI Email classification
- Lead extraction and summarization
